package com.collegedekho.app.display;

/**
 * Created by Bashir on 29/2/16.
 */
public class PagerSlidingTabStrip {
}
