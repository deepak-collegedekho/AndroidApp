package com.collegedekho.app.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.collegedekho.app.R;
import com.collegedekho.app.display.peekandpop.PeekAndPop;
import com.collegedekho.app.entities.Institute;
import com.collegedekho.app.fragment.WishlistFragment;
import com.collegedekho.app.resource.MySingleton;
import com.collegedekho.app.widget.FadeInImageView;

import java.util.ArrayList;

public class WishlistInstituteListAdapter extends RecyclerView.Adapter<WishlistInstituteListAdapter.InstituteHolder> {

    private final ImageLoader mImageLoader;
    private ArrayList<Institute> mInstitutes;
    private Activity mContext;
    // Allows to remember the last item shown on screen
    public int lastPosition = -1;
    private int mViewType;
    private int mPeekPopViewType;
    private PeekAndPop mPeekAndPop;
    private View mPeekView;

    public WishlistInstituteListAdapter(Activity context, ArrayList<Institute> institutes, int type, PeekAndPop peekAndPop) {
        this.mInstitutes = institutes;
        this.mContext = context;
        this.mPeekPopViewType = type;
        this.mPeekAndPop = peekAndPop;
        this.mImageLoader = MySingleton.getInstance(this.mContext).getImageLoader();

        this.mPeekView = this.mPeekAndPop.getPeekView();

        this.mSetupPeekAndPopStandard();
    }

    private void mSetupPeekAndPopStandard() {
        this.mPeekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
            @Override
            public void onPeek(View view, int position) {
            }

            @Override
            public void onPop(View view, int position) {
            }
        });
    }

    @Override
    public InstituteHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        int viewID =  R.layout.card_wishlist_institute_list_grid_view;
        View rootView = LayoutInflater.from(mContext).inflate(viewID, parent, false);
        try {
            return new InstituteHolder(rootView, (WishlistFragment.WishlistInstituteInteractionListener) this.mContext);
        } catch (ClassCastException e) {
            throw new ClassCastException(this.mContext.toString()
                    + " must implement OnInstituteSelectedListener");
        }
    }

    @Override
    public void onBindViewHolder(InstituteHolder holder, int position) {
        Institute institute = this.mInstitutes.get(position);
        InstituteHolder instituteHolder = holder;

        WishlistInstituteListAdapter.this.mPeekAndPop.addLongClickView(instituteHolder.instituteCard, position);

        String text = "";

        if (institute.getAcronym() != null && institute.getAcronym().equalsIgnoreCase("None") && !institute.getAcronym().isEmpty())
            text = institute.getAcronym();
        else if (institute.getShort_name() != null && !institute.getShort_name().equalsIgnoreCase("None") && !institute.getShort_name().isEmpty())
            text += institute.getShort_name();

        if (institute.getCity_name() != null && !institute.getCity_name().isEmpty())
            text += institute.getCity_name();

        instituteHolder.instituteLogo.setDefaultImageResId(R.drawable.ic_cd);
        instituteHolder.instituteLogo.setErrorImageResId(R.drawable.ic_cd);

        if (institute.getLogo() != null && !institute.getLogo().isEmpty())
            instituteHolder.instituteLogo.setImageUrl(institute.getLogo(), this.mImageLoader);

        instituteHolder.instituteShortName.setText(text);
    }

    @Override
    public void onViewDetachedFromWindow(InstituteHolder holder) {
        holder.itemView.clearAnimation();
        super.onViewDetachedFromWindow(holder);
    }

    @Override
    public int getItemCount() {
        return mInstitutes.size();
    }

    public static class InstituteHolder extends RecyclerView.ViewHolder{
        WishlistFragment.WishlistInstituteInteractionListener mListener;
        View instituteCard;

        TextView instituteShortName;
        FadeInImageView instituteLogo;

        public InstituteHolder(View itemView, WishlistFragment.WishlistInstituteInteractionListener listener) {
            super(itemView);
            this.mListener = listener;

            instituteCard = itemView;

            instituteShortName = (TextView) itemView.findViewById(R.id.wishlist_institute_shortname);
            instituteLogo = (FadeInImageView) itemView.findViewById(R.id.wishlist_institute_logo);
        }
    }
}