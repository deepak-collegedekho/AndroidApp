package com.collegedekho.app.resource;

/**
 * Created by harshvardhan on 08/10/15.
 */
public class ErrorCode {

    public static final int LOGIN_EMAIL_ALREADY_EXISTS = 101;
    public static final int LOGIN_USER_INACTIVE = 201;
    public static final int LOGIN_PASSWORD_INCORRECT = 202;
    public static final int LOGIN_PREFERENCE_CONFLICT = 203;
}
