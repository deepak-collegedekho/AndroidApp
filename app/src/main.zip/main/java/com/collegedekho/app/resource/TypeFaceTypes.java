package com.collegedekho.app.resource;

public enum TypeFaceTypes {
	DROID_SERIF_BOLD, DROID_SERIF_BOLD_ITALIC, PROXIMA_NOVA_REGULAR, GOTHAM_BOOK

}
