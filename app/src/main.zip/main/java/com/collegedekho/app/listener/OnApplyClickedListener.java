package com.collegedekho.app.listener;

/**
 * @author Mayank Gautam
 *         Created: 09/07/15
 */
public interface OnApplyClickedListener {
    void onCourseApplied(long id);
}
