package com.collegedekho.app.entities;

/**
 * Created by harsh.vardhan on 23/11/2015.
 */
public class GameEntity {
    public int imageResId;
    public int titleResId;

    public GameEntity(int imageResId, int titleResId){
        this.imageResId = imageResId;
        this.titleResId = titleResId;
    }
}
